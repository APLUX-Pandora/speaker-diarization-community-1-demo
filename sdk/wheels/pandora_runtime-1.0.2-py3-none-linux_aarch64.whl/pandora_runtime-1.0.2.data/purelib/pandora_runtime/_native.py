import ctypes
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def library():
    return ctypes.CDLL(str(Path(__file__).with_name("libpandora_runtime.so.5")))
