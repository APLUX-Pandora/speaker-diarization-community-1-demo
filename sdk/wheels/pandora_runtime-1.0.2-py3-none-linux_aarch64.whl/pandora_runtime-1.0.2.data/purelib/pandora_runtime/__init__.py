# SPDX-License-Identifier: Apache-2.0
"""Pandora Runtime: hardware settings for advanced use (CPU affinity, QNN performance mode,
QNN priority, NPU device).

The native policy library is installed with this package.
"""
import ctypes as _C
import os as _os
import threading as _threading
from types import MappingProxyType as _MappingProxyType

from . import _native
from contextlib import contextmanager

__all__ = ["Runtime", "CpuOptions", "QnnOptions", "RuntimeNativeError"]

_ABI = 5
_MAX_CPUS = 64
_MODES = ("burst", "sustained_high_performance", "high_performance", "balanced", "low_balanced",
          "high_power_saver", "power_saver", "low_power_saver", "extreme_power_saver",
          "system_settings")
_PRIORITIES = {"low": 0, "normal": 100, "normal_high": 150, "high": 200}
_PRIORITY_NAMES = {v: k for k, v in _PRIORITIES.items()}
_ERROR_ARGUMENT = -1


class RuntimeNativeError(RuntimeError):
    """The SDK library refused the settings; ``code`` is a PANDORA_RUNTIME_ERROR_* value."""

    def __init__(self, code, message):
        super().__init__("%s (code %d)" % (message, code))
        self.code = code


class CpuOptions:
    """``affinity``: ``"default"`` (recommended CPUs for the SoC) or a nonempty list of CPU IDs."""

    __slots__ = ("_affinity",)

    def __init__(self, affinity="default"):
        if isinstance(affinity, str):
            if affinity != "default":
                raise ValueError('affinity must be "default" or a nonempty list of CPU IDs')
            value = "default"
        elif isinstance(affinity, (list, tuple)):
            if not affinity:
                raise ValueError("affinity CPU list must not be empty")
            for cpu in affinity:
                if type(cpu) is not int:
                    raise TypeError("CPU IDs must be int (bool and float are rejected)")
                if not 0 <= cpu < _MAX_CPUS:
                    raise ValueError("CPU IDs must be in 0..63")
            if len(set(affinity)) != len(affinity):
                raise ValueError("affinity CPU list has duplicate IDs")
            value = tuple(sorted(affinity))
        else:
            raise TypeError('affinity must be "default" or a list of CPU IDs')
        object.__setattr__(self, "_affinity", value)

    @property
    def affinity(self):
        return self._affinity if self._affinity == "default" else list(self._affinity)

    def __setattr__(self, name, value):
        raise AttributeError("CpuOptions is immutable")

    def __repr__(self):
        return "CpuOptions(affinity=%r)" % (self.affinity,)


class QnnOptions:
    """``performance_mode`` (10 modes), ``priority`` (4 levels) and NPU ``device_id``."""

    __slots__ = ("_performance_mode", "_priority", "_device_id")

    def __init__(self, performance_mode="burst", priority="normal", device_id=0):
        if not isinstance(performance_mode, str):
            raise TypeError("performance_mode must be a str")
        if performance_mode not in _MODES:
            raise ValueError("performance_mode must be one of: " + ", ".join(_MODES))
        if not isinstance(priority, str):
            raise TypeError("priority must be a str")
        if priority not in _PRIORITIES:
            raise ValueError("priority must be one of: " + ", ".join(_PRIORITIES))
        if type(device_id) is not int:
            raise TypeError("device_id must be int (bool and float are rejected)")
        if not 0 <= device_id <= 0xFFFFFFFF:
            raise ValueError("device_id must be a non-negative 32-bit integer")
        object.__setattr__(self, "_performance_mode", performance_mode)
        object.__setattr__(self, "_priority", priority)
        object.__setattr__(self, "_device_id", device_id)

    performance_mode = property(lambda self: self._performance_mode)
    priority = property(lambda self: self._priority)
    device_id = property(lambda self: self._device_id)

    def __setattr__(self, name, value):
        raise AttributeError("QnnOptions is immutable")

    def __repr__(self):
        return "QnnOptions(performance_mode=%r, priority=%r, device_id=%r)" % (
            self._performance_mode, self._priority, self._device_id)


class _Config(_C.Structure):
    _fields_ = [("struct_size", _C.c_uint32), ("abi_version", _C.c_uint32),
                ("cpu_affinity", _C.c_uint32), ("cpu_count", _C.c_uint32),
                ("cpu_ids", _C.POINTER(_C.c_uint32)), ("performance_mode", _C.c_uint32),
                ("priority", _C.c_uint32), ("device_id", _C.c_uint32), ("reserved", _C.c_uint32)]


class _Status(_C.Structure):
    _fields_ = [("struct_size", _C.c_uint32), ("abi_version", _C.c_uint32),
                ("soc_id", _C.c_int32), ("cpu_affinity", _C.c_uint32), ("cpu_count", _C.c_uint32),
                ("cpu_ids", _C.c_uint32 * _MAX_CPUS), ("cpu_mask", _C.c_uint64),
                ("performance_mode", _C.c_uint32), ("priority", _C.c_uint32),
                ("device_id", _C.c_uint32), ("rpc_control_latency_us", _C.c_uint32),
                ("rpc_polling_time_us", _C.c_uint32), ("reserved", _C.c_uint32)]


def _bind(lib):
    if getattr(lib, "_pandora_runtime_bound", False):
        return lib
    lib.pandora_runtime_create.argtypes = [_C.POINTER(_Config), _C.POINTER(_C.c_void_p)]
    lib.pandora_runtime_create.restype = _C.c_int
    lib.pandora_runtime_get_status.argtypes = [_C.c_void_p, _C.POINTER(_Status)]
    lib.pandora_runtime_get_status.restype = _C.c_int
    lib.pandora_runtime_destroy.argtypes = [_C.POINTER(_C.c_void_p)]
    lib.pandora_runtime_destroy.restype = _C.c_int
    lib.pandora_runtime_last_error.argtypes = []
    lib.pandora_runtime_last_error.restype = _C.c_char_p
    lib._pandora_runtime_bound = True
    return lib


def _check(lib, rc):
    if rc != 0:
        message = (lib.pandora_runtime_last_error() or b"").decode("utf-8", "replace")
        if rc == _ERROR_ARGUMENT:
            raise ValueError(message)
        raise RuntimeNativeError(rc, message)


def load_library():
    """Load the installed ABI provider before opening a model shared library."""
    return _native.library()


class Runtime:
    """Hardware settings shared by the models that use it.

    Models loaded without ``runtime=`` (or with ``None``) use the defaults. Settings are fixed
    for the lifetime of the Runtime; to change them, create a new Runtime and reload the model.
    A Runtime belongs to this SDK and this process: do not pass it to another SDK or across fork.
    """

    def __init__(self, *, cpu=None, qnn=None):
        if cpu is None:
            cpu = CpuOptions()
        if qnn is None:
            qnn = QnnOptions()
        if not isinstance(cpu, CpuOptions):
            raise TypeError("cpu must be CpuOptions or None")
        if not isinstance(qnn, QnnOptions):
            raise TypeError("qnn must be QnnOptions or None")
        self._cpu, self._qnn = cpu, qnn
        self._pid = _os.getpid()
        self._lock = _threading.Lock()
        self._handle = _C.c_void_p()
        self._lib = _bind(_native.library())
        affinity = cpu.affinity
        ids = None if affinity == "default" else (_C.c_uint32 * len(affinity))(*affinity)
        config = _Config(_C.sizeof(_Config), _ABI, 0 if ids is None else 1,
                         0 if ids is None else len(affinity), ids,
                         _MODES.index(qnn.performance_mode), _PRIORITIES[qnn.priority],
                         qnn.device_id, 0)
        _check(self._lib, self._lib.pandora_runtime_create(_C.byref(config), _C.byref(self._handle)))

    @property
    def cpu(self):
        return self._cpu

    @property
    def qnn(self):
        return self._qnn

    @property
    def closed(self):
        return not self._handle.value

    def _check_process(self):
        if _os.getpid() != self._pid:
            raise RuntimeError("Runtime was created in another process; create it again after fork")

    def _native_handle(self):
        """For this SDK's model loaders: the native handle (models take their own reference)."""
        self._check_process()
        if not self._handle.value:
            raise RuntimeError("Runtime is closed")
        return self._handle

    @contextmanager
    def borrow_handle(self):
        """Hold a valid ABI handle while a model snapshots the settings."""
        self._check_process()
        with self._lock:
            yield self._native_handle()

    def status(self):
        """Read-only snapshot of the settings submitted to the backend."""
        self._check_process()  # A forked child may inherit a permanently held lock.
        with self._lock:
            handle = self._native_handle()
            out = _Status()
            out.struct_size, out.abi_version = _C.sizeof(_Status), _ABI
            _check(self._lib, self._lib.pandora_runtime_get_status(handle, _C.byref(out)))
        cpus = [out.cpu_ids[i] for i in range(out.cpu_count)]
        return _MappingProxyType({
            "soc_id": None if out.soc_id < 0 else out.soc_id,
            "cpu_affinity": "default" if out.cpu_affinity == 0 else cpus,
            "cpu_mask": "0x%02x" % out.cpu_mask,
            "performance_mode": _MODES[out.performance_mode],
            "priority": _PRIORITY_NAMES[out.priority],
            "device_id": out.device_id,
            "rpc_control_latency_us": out.rpc_control_latency_us,
            "rpc_polling_time_us": out.rpc_polling_time_us,
        })

    def close(self):
        """Release this reference. Safe to call twice; loaded models stay valid."""
        if _os.getpid() != self._pid:
            self._handle = _C.c_void_p()  # the child never owned the parent's handle
            return
        with self._lock:
            if not self._handle.value:
                return
            _check(self._lib, self._lib.pandora_runtime_destroy(_C.byref(self._handle)))

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __repr__(self):
        return "Runtime(cpu=%r, qnn=%r)" % (self._cpu, self._qnn)
